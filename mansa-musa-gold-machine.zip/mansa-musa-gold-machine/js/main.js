const TREASURES = [
  { id: 'gold-coin', label: 'Gold Coin', icon: '🪙', family: 'gold' },
  { id: 'gold-bar', label: 'Gold Bar', icon: '🟨', family: 'gold' },
  { id: 'royal-crown', label: 'Crown', icon: '👑', family: 'royal' },
  { id: 'manuscript', label: 'Manuscript', icon: '📜', family: 'knowledge' },
  { id: 'lantern', label: 'Lantern', icon: '🏺', family: 'trade' },
  { id: 'kora', label: 'Kora', icon: '🎶', family: 'knowledge' },
  { id: 'saddlebag', label: 'Trade Bag', icon: '💰', family: 'trade' },
  { id: 'gem', label: 'Gem', icon: '💎', family: 'royal' }
];

const state = {
  carriageX: 46,
  minX: 46,
  maxX: 46,
  lineHeight: 74,
  baseLineHeight: 74,
  active: true,
  busy: false,
  movingLeft: false,
  movingRight: false,
  collected: 0,
  items: [],
  raf: null,
};

const machine = document.getElementById('machine');
const playfield = document.getElementById('playfield');
const clawCarriage = document.getElementById('clawCarriage');
const clawLine = document.getElementById('clawLine');
const claw = document.getElementById('claw');
const collectionTray = document.getElementById('collectionTray');
const scoreEl = document.getElementById('score');
const totalEl = document.getElementById('total');
const legendGrid = document.getElementById('legendGrid');
const overlay = document.getElementById('winOverlay');
const resetBtn = document.getElementById('resetBtn');
const playAgainBtn = document.getElementById('playAgainBtn');

const leftBtn = document.getElementById('leftBtn');
const rightBtn = document.getElementById('rightBtn');
const dropBtn = document.getElementById('dropBtn');

function setLineHeight(value) {
  state.lineHeight = value;
  clawLine.style.height = `${value}px`;
}

function setCarriageX(x) {
  state.carriageX = Math.max(state.minX, Math.min(state.maxX, x));
  clawCarriage.style.left = `${state.carriageX}px`;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function renderLegend() {
  legendGrid.innerHTML = '';
  TREASURES.forEach((item) => {
    const div = document.createElement('div');
    div.className = 'legend-item';
    div.innerHTML = `
      <div class="legend-token">${item.icon}</div>
      <div>
        <strong>${item.label}</strong>
      </div>
    `;
    legendGrid.appendChild(div);
  });
}

function makeTreasureNode(item, x, y) {
  const node = document.createElement('div');
  node.className = `treasure ${item.family}`;
  node.dataset.id = item.id;
  node.style.left = `${x}px`;
  node.style.top = `${y}px`;
  node.innerHTML = `<div class="icon">${item.icon}</div><div class="name">${item.label}</div>`;
  playfield.appendChild(node);
  return node;
}

function getPlayfieldBounds() {
  return playfield.getBoundingClientRect();
}

function randomJitter(amount) {
  return Math.round((Math.random() - 0.5) * amount * 2);
}

function layoutTreasures() {
  state.items.forEach((item) => item.node.remove());
  state.items = [];
  collectionTray.innerHTML = '';
  state.collected = 0;
  scoreEl.textContent = '0';
  totalEl.textContent = String(TREASURES.length);

  const bounds = getPlayfieldBounds();
  const cols = 4;
  const startY = Math.max(160, bounds.height * 0.36);
  const gapX = (bounds.width - 80) / cols;
  const gapY = Math.min(120, (bounds.height - startY - 50) / 2);

  TREASURES.forEach((item, index) => {
    const col = index % cols;
    const row = Math.floor(index / cols);
    const x = 28 + col * gapX + randomJitter(12);
    const y = startY + row * gapY + randomJitter(10);
    const node = makeTreasureNode(item, x, y);
    state.items.push({ ...item, x, y, node, collected: false });
  });
}

function addToTray(item) {
  const tray = document.createElement('div');
  tray.className = 'tray-item';
  tray.innerHTML = `
    <div class="tray-token">${item.icon}</div>
    <div><strong>${item.label}</strong></div>
  `;
  collectionTray.appendChild(tray);
}

function updateScore() {
  scoreEl.textContent = String(state.collected);
  if (state.collected >= TREASURES.length) {
    overlay.classList.remove('hidden');
    overlay.setAttribute('aria-hidden', 'false');
    state.active = false;
  }
}

function getClawTip() {
  const machineRect = machine.getBoundingClientRect();
  return {
    x: state.carriageX + 29,
    y: state.lineHeight + 58,
    machineRect,
  };
}

function findCatchCandidate() {
  const tip = getClawTip();
  let winner = null;
  let bestDistance = Infinity;

  state.items.forEach((item) => {
    if (item.collected) return;
    const centerX = item.x + 31;
    const centerY = item.y + 31;
    const dx = Math.abs(centerX - tip.x);
    const dy = Math.abs(centerY - tip.y);
    if (dx < 34 && dy < 44) {
      const score = dx + dy * 0.4;
      if (score < bestDistance) {
        bestDistance = score;
        winner = item;
      }
    }
  });

  return winner;
}

async function animateLine(targetHeight, step = 10, delay = 14) {
  const dir = targetHeight > state.lineHeight ? 1 : -1;
  while ((dir > 0 && state.lineHeight < targetHeight) || (dir < 0 && state.lineHeight > targetHeight)) {
    setLineHeight(state.lineHeight + step * dir);
    if ((dir > 0 && state.lineHeight > targetHeight) || (dir < 0 && state.lineHeight < targetHeight)) {
      setLineHeight(targetHeight);
    }
    await sleep(delay);
  }
}

async function animateCarriage(targetX, step = 8, delay = 12) {
  const dir = targetX > state.carriageX ? 1 : -1;
  while ((dir > 0 && state.carriageX < targetX) || (dir < 0 && state.carriageX > targetX)) {
    setCarriageX(state.carriageX + step * dir);
    if ((dir > 0 && state.carriageX > targetX) || (dir < 0 && state.carriageX < targetX)) {
      setCarriageX(targetX);
    }
    await sleep(delay);
  }
}

function mountCapturedItem(item) {
  item.node.classList.add('captured');
  item.node.style.zIndex = '8';
  const x = state.carriageX + 29 - 31;
  const y = state.lineHeight + 54;
  item.node.style.left = `${x}px`;
  item.node.style.top = `${y}px`;
}

async function depositItem(item) {
  const targetX = state.minX + 8;
  await animateCarriage(targetX, 8, 12);
  item.node.style.left = `${state.carriageX + 29 - 31}px`;
  item.node.style.top = `${state.lineHeight + 54}px`;
  await animateLine(state.baseLineHeight + 70, 10, 14);
  item.node.style.left = '10px';
  item.node.style.top = '10px';
  await sleep(120);
  item.collected = true;
  item.node.classList.add('collected');
  addToTray(item);
  state.collected += 1;
  updateScore();
  await sleep(120);
  await animateLine(state.baseLineHeight, 10, 14);
}

async function dropClaw() {
  if (!state.active || state.busy) return;
  state.busy = true;
  claw.classList.add('closed');

  const maxDrop = Math.min(playfield.clientHeight - 10, 350);
  await animateLine(maxDrop, 10, 14);

  const item = findCatchCandidate();
  if (item) {
    mountCapturedItem(item);
  }

  await sleep(120);
  await animateLine(state.baseLineHeight, 10, 14);

  if (item) {
    mountCapturedItem(item);
    await depositItem(item);
  }

  claw.classList.remove('closed');
  state.busy = false;
}

function updateLoop() {
  if (state.active && !state.busy) {
    if (state.movingLeft) setCarriageX(state.carriageX - 4.5);
    if (state.movingRight) setCarriageX(state.carriageX + 4.5);
  }
  state.raf = requestAnimationFrame(updateLoop);
}

function stopMovementFlags() {
  state.movingLeft = false;
  state.movingRight = false;
}

function bindButtonHold(button, onStart, onStop) {
  ['mousedown', 'touchstart'].forEach((eventName) => {
    button.addEventListener(eventName, (event) => {
      event.preventDefault();
      onStart();
    }, { passive: false });
  });

  ['mouseup', 'mouseleave', 'touchend', 'touchcancel'].forEach((eventName) => {
    button.addEventListener(eventName, (event) => {
      event.preventDefault();
      onStop();
    }, { passive: false });
  });
}

function bindControls() {
  bindButtonHold(leftBtn, () => {
    if (state.busy) return;
    state.movingLeft = true;
    state.movingRight = false;
  }, () => {
    state.movingLeft = false;
  });

  bindButtonHold(rightBtn, () => {
    if (state.busy) return;
    state.movingRight = true;
    state.movingLeft = false;
  }, () => {
    state.movingRight = false;
  });

  dropBtn.addEventListener('click', dropClaw);
  resetBtn.addEventListener('click', resetGame);
  playAgainBtn.addEventListener('click', resetGame);

  window.addEventListener('keydown', (event) => {
    if (event.repeat) return;
    if (event.code === 'ArrowLeft') state.movingLeft = true;
    if (event.code === 'ArrowRight') state.movingRight = true;
    if (event.code === 'Space' || event.code === 'ArrowUp') {
      event.preventDefault();
      dropClaw();
    }
  });

  window.addEventListener('keyup', (event) => {
    if (event.code === 'ArrowLeft') state.movingLeft = false;
    if (event.code === 'ArrowRight') state.movingRight = false;
  });

  window.addEventListener('resize', () => {
    computeBounds();
    layoutTreasures();
    setCarriageX(state.minX);
    setLineHeight(state.baseLineHeight);
  });
}

function computeBounds() {
  const width = machine.clientWidth;
  state.minX = 46;
  state.maxX = Math.max(state.minX, width - 46 - 58);
}

function resetGame() {
  overlay.classList.add('hidden');
  overlay.setAttribute('aria-hidden', 'true');
  state.active = true;
  state.busy = false;
  stopMovementFlags();
  computeBounds();
  setCarriageX(state.minX + 18);
  setLineHeight(state.baseLineHeight);
  layoutTreasures();
}

function init() {
  renderLegend();
  computeBounds();
  totalEl.textContent = String(TREASURES.length);
  setCarriageX(state.minX + 18);
  setLineHeight(state.baseLineHeight);
  layoutTreasures();
  bindControls();
  updateLoop();
}

init();
